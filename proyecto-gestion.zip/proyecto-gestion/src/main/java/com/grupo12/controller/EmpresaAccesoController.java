package com.grupo12.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;

@RestController
@RequestMapping("/api/empresas")
public class EmpresaAccesoController {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/flowable";
    private static final String DB_USER = "postgres";
    private static final String DB_PASS = "password";

    private static final String FLOWABLE_BASE_URL = "http://localhost:8080/flowable-ui/process-api";
    private static final String FLOWABLE_USER = "admin";
    private static final String FLOWABLE_PASS = "test";

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    // 1. Habilitar o reutilizar cuenta de empresa (llamado por HTTP Task de Flowable o por prueba)
    @PostMapping("/habilitar-acceso")
    public ResponseEntity<Object> habilitarAcceso(@RequestBody Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();
        String processInstanceId = body.get("processInstanceId") != null ? body.get("processInstanceId").toString() : null;
        String cuitParam = body.get("cuit") != null ? body.get("cuit").toString() : null;

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                conn.setAutoCommit(false);

                int empresaId = 0;
                Integer cursoId = null;

                if (processInstanceId != null && !processInstanceId.isBlank()) {
                    String sqlBuscarCurso = "SELECT id, empresa_id FROM curso WHERE process_instance_id = ?";
                    try (PreparedStatement ps = conn.prepareStatement(sqlBuscarCurso)) {
                        ps.setString(1, processInstanceId.trim());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                cursoId = rs.getInt("id");
                                empresaId = rs.getInt("empresa_id");
                            }
                        }
                    }
                }

                if (empresaId == 0 && cuitParam != null && !cuitParam.isBlank()) {
                    String sqlBuscarEmpresa = "SELECT id FROM empresa WHERE cuit = ?";
                    try (PreparedStatement ps = conn.prepareStatement(sqlBuscarEmpresa)) {
                        ps.setString(1, cuitParam.trim());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                empresaId = rs.getInt("id");
                            }
                        }
                    }
                }

                if (empresaId == 0) {
                    conn.rollback();
                    resp.put("status", "error");
                    resp.put("message", "No se encontro empresa asociada para habilitar acceso.");
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(resp);
                }

                String cuit = "";
                String nombre = "";
                String usuarioActual = null;
                String claveActual = null;

                String sqlEmpresa = "SELECT cuit, nombre, usuario, clave FROM empresa WHERE id = ?";
                try (PreparedStatement ps = conn.prepareStatement(sqlEmpresa)) {
                    ps.setInt(1, empresaId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            cuit = rs.getString("cuit");
                            nombre = rs.getString("nombre");
                            usuarioActual = rs.getString("usuario");
                            claveActual = rs.getString("clave");
                        }
                    }
                }

                boolean cuentaNueva = false;
                if (usuarioActual == null || usuarioActual.isBlank()) {
                    String limpio = cuit.replaceAll("[^0-9]", "");
                    String ultimos4 = limpio.length() >= 4 ? limpio.substring(limpio.length() - 4) : "1234";
                    usuarioActual = "emp_" + limpio;
                    claveActual = "pass_" + ultimos4;
                    cuentaNueva = true;
                }

                String sqlUpdateEmpresa = "UPDATE empresa SET usuario = ?, clave = ?, acceso_habilitado = TRUE WHERE id = ?";
                try (PreparedStatement ps = conn.prepareStatement(sqlUpdateEmpresa)) {
                    ps.setString(1, usuarioActual);
                    ps.setString(2, claveActual);
                    ps.setInt(3, empresaId);
                    ps.executeUpdate();
                }

                if (cursoId != null) {
                    String sqlUpdateCurso = "UPDATE curso SET estado = 'EN_PREPARACION' WHERE id = ? AND estado = 'EN_EVALUACION'";
                    try (PreparedStatement ps = conn.prepareStatement(sqlUpdateCurso)) {
                        ps.setInt(1, cursoId);
                        ps.executeUpdate();
                    }
                }

                conn.commit();

                resp.put("status", "success");
                resp.put("cuentaCreada", cuentaNueva);
                resp.put("cuentaReutilizada", !cuentaNueva);
                resp.put("empresaId", empresaId);
                resp.put("nombreEmpresa", nombre);
                resp.put("usuario", usuarioActual);
                resp.put("clave", claveActual);
                resp.put("accesoHabilitado", true);
                return ResponseEntity.ok(resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    // 2. Login de empresa
    @PostMapping("/login")
    public ResponseEntity<Object> loginEmpresa(@RequestBody LoginDTO dto) {
        Map<String, Object> resp = new HashMap<>();

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT id, cuit, nombre, email_contacto, telefono_contacto, usuario, acceso_habilitado " +
                             "FROM empresa WHERE usuario = ? AND clave = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, dto.getUsuario());
                    ps.setString(2, dto.getClave());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            resp.put("status", "error");
                            resp.put("message", "Usuario o clave incorrectos.");
                            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(resp);
                        }

                        boolean habilitado = rs.getBoolean("acceso_habilitado");
                        if (!habilitado) {
                            resp.put("status", "error");
                            resp.put("message", "El acceso de la empresa aun no esta habilitado.");
                            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(resp);
                        }

                        Map<String, Object> empresa = new HashMap<>();
                        empresa.put("id", rs.getInt("id"));
                        empresa.put("cuit", rs.getString("cuit"));
                        empresa.put("nombre", rs.getString("nombre"));
                        empresa.put("emailContacto", rs.getString("email_contacto"));
                        empresa.put("telefonoContacto", rs.getString("telefono_contacto"));
                        empresa.put("usuario", rs.getString("usuario"));

                        resp.put("status", "success");
                        resp.put("empresa", empresa);
                        return ResponseEntity.ok(resp);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    // 3. Consultar cursos de una empresa y su estado
    @GetMapping("/{empresaId}/cursos")
    public ResponseEntity<Object> listarCursosEmpresa(@PathVariable int empresaId) {
        List cursos = new ArrayList<>();
        Map<String, Object> resp = new HashMap<>();

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT id, process_instance_id, nombre, descripcion, cantidad_participantes, " +
                             "fechas_preferidas, fecha_inicio, fecha_fin, estado, informe_resultados " +
                             "FROM curso WHERE empresa_id = ? ORDER BY id DESC";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, empresaId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            Map<String, Object> c = new HashMap<>();
                            c.put("id", rs.getInt("id"));
                            c.put("processInstanceId", rs.getString("process_instance_id"));
                            c.put("nombre", rs.getString("nombre"));
                            c.put("descripcion", rs.getString("descripcion"));
                            c.put("cantidadParticipantes", rs.getObject("cantidad_participantes"));
                            c.put("fechasPreferidas", rs.getString("fechas_preferidas"));
                            c.put("fechaInicio", rs.getDate("fecha_inicio"));
                            c.put("fechaFin", rs.getDate("fecha_fin"));
                            c.put("estado", rs.getString("estado"));
                            c.put("estadoLegible", formatearEstado(rs.getString("estado")));
                            c.put("informeResultados", rs.getString("informe_resultados"));
                            cursos.add(c);
                        }
                    }
                }
            }

            resp.put("status", "success");
            resp.put("cursos", cursos);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    // 4. Consultar actividades pendientes / en ejecucion (contemplando ramas paralelas)
    @GetMapping("/instancias/{processInstanceId}/actividades-activas")
    public ResponseEntity<Object> consultarActividadesActivas(@PathVariable String processInstanceId) {
        Map<String, Object> resp = new HashMap<>();

        try {
            String auth = Base64.getEncoder().encodeToString(
                    (FLOWABLE_USER + ":" + FLOWABLE_PASS).getBytes(StandardCharsets.UTF_8));
            HttpClient client = HttpClient.newHttpClient();

            // Tareas humanas activas
            HttpRequest reqTasks = HttpRequest.newBuilder()
                    .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/tasks?processInstanceId=" + processInstanceId))
                    .header("Authorization", "Basic " + auth)
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> resTasks = client.send(reqTasks, HttpResponse.BodyHandlers.ofString());

            List tareasActivas = new ArrayList<>();
            if (resTasks.statusCode() == 200) {
                JsonNode tasksData = OBJECT_MAPPER.readTree(resTasks.body()).path("data");
                for (JsonNode t : tasksData) {
                    Map<String, Object> item = new HashMap<>();
                    item.put("id", t.path("id").asText());
                    item.put("name", t.path("name").asText());
                    item.put("taskDefinitionKey", t.path("taskDefinitionKey").asText());
                    item.put("assignee", t.path("assignee").isNull() ? null : t.path("assignee").asText());
                    item.put("executionId", t.path("executionId").asText());
                    tareasActivas.add(item);
                }
            }

            // Ejecuciones activas (util para ver ramas paralelas abiertas)
            HttpRequest reqExec = HttpRequest.newBuilder()
                    .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/executions?processInstanceId=" + processInstanceId))
                    .header("Authorization", "Basic " + auth)
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> resExec = client.send(reqExec, HttpResponse.BodyHandlers.ofString());

            List ramasActivas = new ArrayList<>();
            if (resExec.statusCode() == 200) {
                JsonNode execData = OBJECT_MAPPER.readTree(resExec.body()).path("data");
                for (JsonNode ex : execData) {
                    String actId = ex.path("activityId").asText("");
                    if (!actId.isBlank()) {
                        Map<String, Object> rama = new HashMap<>();
                        rama.put("executionId", ex.path("id").asText());
                        rama.put("activityId", actId);
                        rama.put("activityName", ex.path("activityName").asText(""));
                        rama.put("suspended", ex.path("suspended").asBoolean(false));
                        ramasActivas.add(rama);
                    }
                }
            }

            resp.put("status", "success");
            resp.put("processInstanceId", processInstanceId);
            resp.put("cantidadTareasActivas", tareasActivas.size());
            resp.put("tareasActivas", tareasActivas);
            resp.put("cantidadRamasActivas", ramasActivas.size());
            resp.put("ramasActivas", ramasActivas);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    private String formatearEstado(String estado) {
        if (estado == null) {
            return "Desconocido";
        }
        switch (estado.toUpperCase()) {
            case "EN_EVALUACION":
                return "En evaluación";
            case "EN_PREPARACION":
                return "En preparación";
            case "CONFIRMADO_PENDIENTE_INICIO":
            case "CONFIRMADO":
                return "Confirmado y pendiente de inicio";
            case "EN_DESARROLLO":
                return "En desarrollo";
            case "ELABORACION_INFORME":
            case "EN_ELABORACION_INFORME":
                return "En elaboración del informe";
            case "FINALIZADO":
                return "Finalizado";
            case "CANCELADO":
                return "Cancelado";
            default:
                return estado;
        }
    }

    public static class LoginDTO {
        private String usuario;
        private String clave;

        public String getUsuario() { return usuario; }
        public void setUsuario(String usuario) { this.usuario = usuario; }
        public String getClave() { return clave; }
        public void setClave(String clave) { this.clave = clave; }
    }
}