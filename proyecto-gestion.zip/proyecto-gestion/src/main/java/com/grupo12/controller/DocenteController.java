package com.grupo12.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

@RestController
@RequestMapping("/api/docente")
public class DocenteController {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/flowable";
    private static final String DB_USER = "postgres";
    private static final String DB_PASS = "password";

    private static final String FLOWABLE_BASE_URL = "http://localhost:8080/flowable-ui/process-api";
    private static final String FLOWABLE_REST_USER = "admin";
    private static final String FLOWABLE_REST_PASS = "test";
    private static final String GRUPO_DOCENTES = "docentes";
    private static final String JEFE_DOCENTE = "jefe_docente";

    private static final Set<String> DOCENTES_VALIDOS = Set.of("jefe_docente", "docente_2", "docente_3");
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @PostMapping("/login")
    public ResponseEntity<Object> login(@RequestBody Map<String, String> body) {
        String usuario = str(body != null ? body.get("usuario") : null);
        String clave = str(body != null ? body.get("clave") : null);
        Map<String, Object> resp = new HashMap<>();

        if (usuario.isBlank() || clave.isBlank()) {
            resp.put("status", "error");
            resp.put("message", "Debe ingresar usuario y clave.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT u.id_, u.first_, u.last_, u.email_ " +
                             "FROM act_id_user u " +
                             "JOIN act_id_membership m ON u.id_ = m.user_id_ " +
                             "WHERE u.id_ = ? AND u.pwd_ = ? AND m.group_id_ = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, usuario);
                    ps.setString(2, clave);
                    ps.setString(3, GRUPO_DOCENTES);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            resp.put("status", "error");
                            resp.put("message", "Credenciales inválidas o el usuario no pertenece a Docentes.");
                            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(resp);
                        }

                        Map<String, Object> docenteUser = new HashMap<>();
                        docenteUser.put("usuario", rs.getString("id_"));
                        docenteUser.put("nombre", rs.getString("first_"));
                        docenteUser.put("apellido", rs.getString("last_"));
                        docenteUser.put("email", rs.getString("email_"));
                        docenteUser.put("grupo", GRUPO_DOCENTES);
                        docenteUser.put("esJefe", JEFE_DOCENTE.equals(rs.getString("id_")));

                        resp.put("status", "success");
                        resp.put("docente", docenteUser);
                        return ResponseEntity.ok(resp);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/integrantes")
    public ResponseEntity<Object> listarIntegrantes() {
        Map<String, Object> resp = new HashMap<>();
        List integrantes = new ArrayList();

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT u.id_, u.first_, u.last_, u.email_ " +
                             "FROM act_id_user u " +
                             "JOIN act_id_membership m ON u.id_ = m.user_id_ " +
                             "WHERE m.group_id_ = ? " +
                             "ORDER BY CASE WHEN u.id_ = ? THEN 0 ELSE 1 END, u.id_";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, GRUPO_DOCENTES);
                    ps.setString(2, JEFE_DOCENTE);

                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            Map item = new HashMap();
                            String id = rs.getString("id_");
                            String nombre = rs.getString("first_");
                            String apellido = rs.getString("last_");
                            item.put("id", id);
                            item.put("nombre", nombre);
                            item.put("apellido", apellido);
                            item.put("nombreCompleto", (nombre + " " + apellido).trim());
                            item.put("email", rs.getString("email_"));
                            item.put("esJefe", JEFE_DOCENTE.equals(id));
                            integrantes.add(item);
                        }
                    }
                }
            }

            resp.put("status", "success");
            resp.put("integrantes", integrantes);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/tareas")
    public ResponseEntity<Object> listarTareas(@RequestParam String usuario) {
        String userTrim = str(usuario);
        Map<String, Object> resp = new HashMap<>();

        if (userTrim.isBlank()) {
            resp.put("status", "error");
            resp.put("message", "Debe indicar el usuario docente.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            String usuarioEnc = URLEncoder.encode(userTrim, StandardCharsets.UTF_8);
            String grupoEnc = URLEncoder.encode(GRUPO_DOCENTES, StandardCharsets.UTF_8);

            List sinAsignarGrupo = consultarFlowableTasks(
                    FLOWABLE_BASE_URL + "/runtime/tasks?candidateGroup=" + grupoEnc + "&unassigned=true&size=100"
            );
            for (Object obj : sinAsignarGrupo) {
                Map t = (Map) obj;
                String defKey = str(t.get("taskDefinitionKey"));
                String procInstId = str(t.get("processInstanceId"));
                if ("Dictar".equals(defKey) && !procInstId.isBlank()) {
                    String docenteElegido = obtenerDocenteSeleccionado(procInstId);
                    if (userTrim.equals(docenteElegido)) {
                        reclamarTareaInterna(str(t.get("id")), userTrim);
                    }
                }
            }

            List asignadas = consultarFlowableTasks(
                    FLOWABLE_BASE_URL + "/runtime/tasks?assignee=" + usuarioEnc + "&size=100"
            );

            resp.put("status", "success");
            resp.put("usuario", userTrim);
            resp.put("grupo", GRUPO_DOCENTES);
            resp.put("asignadas", asignadas);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/definir-docente")
    public ResponseEntity<Object> definirDocente(@PathVariable String taskId, @RequestBody Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        String usuario = str(body != null ? body.get("usuario") : null);
        boolean esJefe = toBool(body != null ? body.get("esJefe") : null) || JEFE_DOCENTE.equals(usuario);
        String docenteId = str(body != null ? body.get("docenteId") : null);
        String processInstanceId = str(body != null ? body.get("processInstanceId") : null);

        if (!esJefe) {
            resp.put("status", "error");
            resp.put("message", "Solo el jefe del equipo docente puede definir el docente para desarrollar el curso.");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(resp);
        }

        if (docenteId.isBlank() || !DOCENTES_VALIDOS.contains(docenteId)) {
            resp.put("status", "error");
            resp.put("message", "Debe seleccionar un integrante válido del equipo docente.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            List variables = new ArrayList();
            variables.add(varFlowable("seleccionarDocente", docenteId));
            variables.add(varFlowable("docenteAsignado", docenteId));

            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");
            payload.put("variables", variables);

            completarEnFlowable(taskId, payload);

            if (!processInstanceId.isBlank()) {
                asignarTareaDictarSiExiste(processInstanceId, docenteId);
            }

            resp.put("status", "success");
            resp.put("message", "Docente '" + docenteId + "' asignado y tarea completada correctamente.");
            resp.put("docenteSeleccionado", docenteId);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/completar")
    public ResponseEntity<Object> completarTarea(@PathVariable String taskId, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");
            if (body != null && body.get("variables") instanceof List) {
                payload.put("variables", body.get("variables"));
            }

            completarEnFlowable(taskId, payload);

            resp.put("status", "success");
            resp.put("message", "Tarea completada correctamente.");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
        }
    }

    private void asignarTareaDictarSiExiste(String processInstanceId, String docenteId) {
        try {
            String procEnc = URLEncoder.encode(processInstanceId, StandardCharsets.UTF_8);
            List tasks = consultarFlowableTasks(
                    FLOWABLE_BASE_URL + "/runtime/tasks?processInstanceId=" + procEnc + "&size=100"
            );
            for (Object obj : tasks) {
                Map t = (Map) obj;
                if ("Dictar".equals(str(t.get("taskDefinitionKey")))) {
                    reclamarTareaInterna(str(t.get("id")), docenteId);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private String obtenerDocenteSeleccionado(String processInstanceId) {
        try {
            String procEnc = URLEncoder.encode(processInstanceId, StandardCharsets.UTF_8);
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/process-instances/" + procEnc + "/variables/seleccionarDocente"))
                    .header("Authorization", "Basic " + basicAuth())
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() == 200) {
                JsonNode valNode = OBJECT_MAPPER.readTree(res.body()).path("value");
                if (!valNode.isMissingNode() && !valNode.isNull()) {
                    return valNode.asText().trim();
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private void reclamarTareaInterna(String taskId, String usuario) throws Exception {
        if (taskId == null || taskId.isBlank() || usuario == null || usuario.isBlank()) return;
        HttpClient client = HttpClient.newHttpClient();
        Map<String, Object> payload = new HashMap<>();
        payload.put("action", "claim");
        payload.put("assignee", usuario);
        String jsonBody = OBJECT_MAPPER.writeValueAsString(payload);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/tasks/" + taskId))
                .header("Authorization", "Basic " + basicAuth())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();
        client.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private void completarEnFlowable(String taskId, Map<String, Object> payload) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        String jsonBody = OBJECT_MAPPER.writeValueAsString(payload);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/tasks/" + taskId))
                .header("Authorization", "Basic " + basicAuth())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() < 200 || res.statusCode() >= 300) {
            throw new RuntimeException("Flowable rechazó completar la tarea (HTTP " + res.statusCode() + "): " + res.body());
        }
    }

    private List consultarFlowableTasks(String url) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Basic " + basicAuth())
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
        List lista = new ArrayList();

        if (res.statusCode() == 200) {
            JsonNode data = OBJECT_MAPPER.readTree(res.body()).path("data");
            for (JsonNode t : data) {
                Map item = new HashMap();
                item.put("id", t.path("id").asText());
                item.put("name", t.path("name").asText());
                item.put("taskDefinitionKey", t.path("taskDefinitionKey").asText());
                item.put("formKey", t.path("formKey").isNull() ? "" : t.path("formKey").asText());
                item.put("assignee", t.path("assignee").isNull() ? null : t.path("assignee").asText());
                item.put("processInstanceId", t.path("processInstanceId").asText());
                item.put("createTime", t.path("createTime").asText());
                lista.add(item);
            }
        }
        return lista;
    }

    private Map<String, Object> varFlowable(String name, Object value) {
        Map<String, Object> v = new HashMap<>();
        v.put("name", name);
        v.put("value", value);
        return v;
    }

    private boolean toBool(Object val) {
        if (val instanceof Boolean) return (Boolean) val;
        if (val == null) return false;
        return Boolean.parseBoolean(val.toString().trim());
    }

    private String str(Object o) {
        return o == null ? "" : o.toString().trim();
    }

    private String basicAuth() {
        return Base64.getEncoder().encodeToString(
                (FLOWABLE_REST_USER + ":" + FLOWABLE_REST_PASS).getBytes(StandardCharsets.UTF_8)
        );
    }
}