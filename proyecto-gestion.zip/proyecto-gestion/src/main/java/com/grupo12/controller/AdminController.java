package com.grupo12.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.grupo12.util.PropuestaPdfGenerator;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/flowable";
    private static final String DB_USER = "postgres";
    private static final String DB_PASS = "password";

    private static final String FLOWABLE_BASE_URL = "http://localhost:8080/flowable-ui/process-api";
    private static final String FLOWABLE_REST_USER = "admin";
    private static final String FLOWABLE_REST_PASS = "test";
    private static final String GRUPO_ADMIN = "administracion";

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @PostMapping("/login")
    public ResponseEntity<Object> login(@RequestBody Map<String, String> body) {
        String usuario = body.get("usuario") != null ? body.get("usuario").trim() : "";
        String clave = body.get("clave") != null ? body.get("clave").trim() : "";
        Map<String, Object> resp = new HashMap<>();

        if (usuario.isBlank() || clave.isBlank()) {
            resp.put("status", "error");
            resp.put("message", "Debe ingresar usuario y clave.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT u.id_, u.first_, u.last_, u.email_ " +
                             "FROM act_id_user u " +
                             "JOIN act_id_membership m ON u.id_ = m.user_id_ " +
                             "WHERE u.id_ = ? AND u.pwd_ = ? AND m.group_id_ = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, usuario);
                    ps.setString(2, clave);
                    ps.setString(3, GRUPO_ADMIN);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            resp.put("status", "error");
                            resp.put("message", "Credenciales inválidas o el usuario no pertenece a Administración.");
                            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(resp);
                        }

                        Map<String, Object> adminUser = new HashMap<>();
                        adminUser.put("usuario", rs.getString("id_"));
                        adminUser.put("nombre", rs.getString("first_"));
                        adminUser.put("apellido", rs.getString("last_"));
                        adminUser.put("email", rs.getString("email_"));
                        adminUser.put("grupo", GRUPO_ADMIN);
                        adminUser.put("esJefe", "jefe_admin".equals(rs.getString("id_")));

                        resp.put("status", "success");
                        resp.put("admin", adminUser);
                        return ResponseEntity.ok(resp);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/tareas")
    public ResponseEntity<Object> listarTareas(@RequestParam String usuario) {
        Map<String, Object> resp = new HashMap<>();

        try {
            String usuarioEnc = URLEncoder.encode(usuario.trim(), StandardCharsets.UTF_8);
            String grupoEnc = URLEncoder.encode(GRUPO_ADMIN, StandardCharsets.UTF_8);

            List asignadas = consultarFlowableTasks(
                    FLOWABLE_BASE_URL + "/runtime/tasks?assignee=" + usuarioEnc + "&size=100"
            );

            List disponiblesGrupo = consultarFlowableTasks(
                    FLOWABLE_BASE_URL + "/runtime/tasks?candidateGroup=" + grupoEnc + "&unassigned=true&size=100"
            );

            resp.put("status", "success");
            resp.put("usuario", usuario);
            resp.put("grupo", GRUPO_ADMIN);
            resp.put("asignadas", asignadas);
            resp.put("disponiblesGrupo", disponiblesGrupo);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/reclamar")
    public ResponseEntity<Object> reclamarTarea(@PathVariable String taskId, @RequestBody Map<String, String> body) {
        String usuario = body.get("usuario") != null ? body.get("usuario").trim() : "";
        Map<String, Object> resp = new HashMap<>();

        if (usuario.isBlank()) {
            resp.put("status", "error");
            resp.put("message", "Falta el usuario que reclama la tarea.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            HttpClient client = HttpClient.newHttpClient();
            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "claim");
            payload.put("assignee", usuario);

            String jsonBody = OBJECT_MAPPER.writeValueAsString(payload);

            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/tasks/" + taskId))
                    .header("Authorization", "Basic " + basicAuth())
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() >= 200 && res.statusCode() < 300) {
                resp.put("status", "success");
                resp.put("message", "Tarea reclamada correctamente.");
                return ResponseEntity.ok(resp);
            } else {
                resp.put("status", "error");
                resp.put("message", "Flowable rechazó el reclamo (HTTP " + res.statusCode() + "): " + res.body());
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/completar")
    public ResponseEntity<Object> completarTarea(@PathVariable String taskId, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");

            if (body != null && body.get("variables") instanceof List) {
                payload.put("variables", body.get("variables"));
            }

            completarEnFlowable(taskId, payload);
            resp.put("status", "success");
            resp.put("message", "Tarea completada correctamente.");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/evaluar-recursos")
    public ResponseEntity<Object> evaluarRecursos(@PathVariable String taskId, @RequestBody Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        boolean aulaFisica = toBool(body != null ? body.get("aulaFisica") : null);
        boolean aulaVirtual = toBool(body != null ? body.get("aulaVirtual") : null);
        boolean equipamientoEspecial = toBool(body != null ? body.get("equipamientoEspecial") : null);
        boolean hayAulasDisponibles = toBool(body != null ? body.get("hayAulasDisponibles") : null);

        List<String> recursosSeleccionados = new ArrayList<>();
        if (aulaFisica) {
            recursosSeleccionados.add("Presencial");
        }
        if (aulaVirtual) {
            recursosSeleccionados.add("Virtual");
        }
        if (equipamientoEspecial) {
            recursosSeleccionados.add("Equipamiento");
        }

        if (recursosSeleccionados.isEmpty()) {
            resp.put("status", "error");
            resp.put("message", "Debe seleccionar al menos una alternativa: aula física, aula virtual o equipamiento especial.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            List variables = new ArrayList<>();
            variables.add(varFlowable("recursosRequeridos", recursosSeleccionados));
            variables.add(varFlowable("requiereAulaFisica", aulaFisica));
            variables.add(varFlowable("requiereAulaVirtual", aulaVirtual));
            variables.add(varFlowable("requiereEquipamientoEspecial", equipamientoEspecial));
            variables.add(varFlowable("hayAulasDisponibles", hayAulasDisponibles));

            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");
            payload.put("variables", variables);

            completarEnFlowable(taskId, payload);

            resp.put("status", "success");
            resp.put("message", "Recursos evaluados y tarea completada correctamente.");
            resp.put("recursosRequeridos", recursosSeleccionados);
            resp.put("hayAulasDisponibles", hayAulasDisponibles);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/instancias/{processInstanceId}/informe")
    public ResponseEntity<Object> consultarInformeResultados(
            @PathVariable String processInstanceId,
            @RequestParam(required = false) String usuario
    ) {
        Map<String, Object> resp = new HashMap<>();

        if (usuario != null && !usuario.isBlank() && !"jefe_admin".equals(usuario.trim())) {
            resp.put("status", "error");
            resp.put("message", "Solo el jefe administrativo puede consultar el informe de resultados.");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(resp);
        }

        try {
            Object informe = obtenerVariableInforme(processInstanceId);
            resp.put("status", "success");
            resp.put("processInstanceId", processInstanceId);
            resp.put("informeResultados", informe);
            resp.put("disponible", informe != null && !informe.toString().isBlank());
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/enviar-informe")
    public ResponseEntity<Object> enviarInformeYArchivar(@PathVariable String taskId, @RequestBody Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        String usuario = str(body != null ? body.get("usuario") : null);
        boolean esJefe = toBool(body != null ? body.get("esJefe") : null) || "jefe_admin".equals(usuario);
        String observaciones = str(body != null ? body.get("observaciones") : null);

        if (!esJefe) {
            resp.put("status", "error");
            resp.put("message", "Solo el jefe administrativo puede enviar el informe a la empresa y archivar el expediente.");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(resp);
        }

        try {
            List variables = new ArrayList<>();
            variables.add(varFlowable("informeEnviadoEmpresa", true));
            variables.add(varFlowable("expedienteArchivado", true));
            if (!observaciones.isBlank()) {
                variables.add(varFlowable("observacionesCierreInforme", observaciones));
            }

            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");
            payload.put("variables", variables);

            completarEnFlowable(taskId, payload);

            resp.put("status", "success");
            resp.put("message", "Informe enviado a la empresa y expediente archivado correctamente.");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @PostMapping("/tareas/{taskId}/propuesta")
    public ResponseEntity<Object> completarConPropuestaPdf(@PathVariable String taskId, @RequestBody Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        String processInstanceId = str(body.get("processInstanceId"));
        String tipoTarea = str(body.get("tipoTarea"));
        String usuario = str(body.get("usuario"));
        String titulo = str(body.get("titulo"));
        String programa = str(body.get("programa"));
        String presupuestoStr = str(body.get("presupuesto"));
        String fechaInicioStr = str(body.get("fechaInicio"));
        String observaciones = str(body.get("observaciones"));

        if (titulo.isBlank() || programa.isBlank()) {
            resp.put("status", "error");
            resp.put("message", "Debe completar al menos el título/resumen y el programa o detalle de la propuesta.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            int version = PropuestaPdfGenerator.siguienteVersion(processInstanceId);
            String archivoNombre = PropuestaPdfGenerator.generarPdf(
                    processInstanceId,
                    tipoTarea.isBlank() ? "Propuesta" : tipoTarea,
                    version,
                    titulo,
                    programa,
                    presupuestoStr,
                    observaciones,
                    usuario
            );

            actualizarCursoPropuesta(processInstanceId, programa, presupuestoStr, fechaInicioStr);

            List variables = new ArrayList<>();
            variables.add(varFlowable("programa", programa));
            if (!presupuestoStr.isBlank()) {
                try {
                    variables.add(varFlowable("presupuesto", Double.parseDouble(presupuestoStr.replace(",", ".").trim())));
                } catch (NumberFormatException e) {
                    variables.add(varFlowable("presupuesto", presupuestoStr.trim()));
                }
            }
            if (!fechaInicioStr.isBlank()) {
                variables.add(varFlowable("fechaInicio", fechaInicioStr.trim()));
            }
            variables.add(varFlowable("versionPropuesta", version));
            variables.add(varFlowable("pdfPropuesta", archivoNombre));
            variables.add(varFlowable("resumenPropuesta", titulo));

            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");
            payload.put("variables", variables);

            completarEnFlowable(taskId, payload);

            String urlPdf = "/api/admin/propuestas/" +
                    URLEncoder.encode(processInstanceId, StandardCharsets.UTF_8) +
                    "/pdf?version=" + version;

            resp.put("status", "success");
            resp.put("message", "Propuesta registrada y PDF v" + version + " generado.");
            resp.put("version", version);
            resp.put("archivo", archivoNombre);
            resp.put("urlPdf", urlPdf);
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/propuestas/{processInstanceId}/pdf")
    public ResponseEntity<Resource> descargarPdf(
            @PathVariable String processInstanceId,
            @RequestParam(defaultValue = "1") int version
    ) {
        try {
            Path archivo = PropuestaPdfGenerator.resolverArchivoVersion(processInstanceId, version);
            if (!Files.exists(archivo)) {
                return ResponseEntity.notFound().build();
            }
            byte[] bytes = Files.readAllBytes(archivo);
            ByteArrayResource resource = new ByteArrayResource(bytes);

            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_PDF)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + archivo.getFileName().toString() + "\"")
                    .contentLength(bytes.length)
                    .body(resource);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/tareas/{taskId}/archivar")
    public ResponseEntity<Object> archivarSolicitud(@PathVariable String taskId, @RequestBody Map<String, Object> body) {
        Map<String, Object> resp = new HashMap<>();

        String processInstanceId = str(body.get("processInstanceId"));
        String motivo = str(body.get("motivo"));
        String observaciones = str(body.get("observaciones"));

        if (motivo.isBlank()) {
            resp.put("status", "error");
            resp.put("message", "Debe indicar el motivo por el cual se archiva la solicitud.");
            return ResponseEntity.badRequest().body(resp);
        }

        try {
            marcarCursoArchivado(processInstanceId, motivo, observaciones);

            List variables = new ArrayList<>();
            variables.add(varFlowable("motivoArchivo", motivo));
            variables.add(varFlowable("observacionesArchivo", observaciones));

            Map<String, Object> payload = new HashMap<>();
            payload.put("action", "complete");
            payload.put("variables", variables);

            completarEnFlowable(taskId, payload);

            resp.put("status", "success");
            resp.put("message", "Solicitud archivada correctamente.");
            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("status", "error");
            resp.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    private Object obtenerVariableInforme(String processInstanceId) throws Exception {
        if (processInstanceId == null || processInstanceId.isBlank()) {
            return null;
        }
        String instEnc = URLEncoder.encode(processInstanceId.trim(), StandardCharsets.UTF_8);
        HttpClient client = HttpClient.newHttpClient();

        HttpRequest runtimeReq = HttpRequest.newBuilder()
                .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/process-instances/" + instEnc + "/variables/informeResultados"))
                .header("Authorization", "Basic " + basicAuth())
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> runtimeRes = client.send(runtimeReq, HttpResponse.BodyHandlers.ofString());
        if (runtimeRes.statusCode() == 200) {
            JsonNode root = OBJECT_MAPPER.readTree(runtimeRes.body());
            JsonNode valNode = root.path("value");
            if (!valNode.isMissingNode() && !valNode.isNull()) {
                return OBJECT_MAPPER.convertValue(valNode, Object.class);
            }
        }

        HttpRequest histReq = HttpRequest.newBuilder()
                .uri(URI.create(FLOWABLE_BASE_URL + "/history/historic-variable-instances?processInstanceId=" + instEnc + "&variableName=informeResultados"))
                .header("Authorization", "Basic " + basicAuth())
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> histRes = client.send(histReq, HttpResponse.BodyHandlers.ofString());
        if (histRes.statusCode() == 200) {
            JsonNode data = OBJECT_MAPPER.readTree(histRes.body()).path("data");
            if (data.isArray() && data.size() > 0) {
                JsonNode valNode = data.get(0).path("value");
                if (!valNode.isMissingNode() && !valNode.isNull()) {
                    return OBJECT_MAPPER.convertValue(valNode, Object.class);
                }
            }
        }

        return null;
    }

    private void actualizarCursoPropuesta(String processInstanceId, String programa, String presupuestoStr, String fechaInicioStr) {
        if (processInstanceId == null || processInstanceId.isBlank()) return;
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                BigDecimal presupuesto = null;
                if (presupuestoStr != null && !presupuestoStr.isBlank()) {
                    try {
                        presupuesto = new BigDecimal(presupuestoStr.replace(",", ".").trim());
                    } catch (NumberFormatException ignored) {
                    }
                }

                java.sql.Date fechaInicioSql = null;
                if (fechaInicioStr != null && !fechaInicioStr.isBlank()) {
                    try {
                        fechaInicioSql = java.sql.Date.valueOf(LocalDate.parse(fechaInicioStr.trim()));
                    } catch (Exception ignored) {
                    }
                }

                String sql = "UPDATE curso SET programa = COALESCE(NULLIF(?, ''), programa), " +
                             "presupuesto = COALESCE(?, presupuesto), " +
                             "fecha_inicio = COALESCE(?, fecha_inicio) " +
                             "WHERE process_instance_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, programa);
                    ps.setBigDecimal(2, presupuesto);
                    ps.setDate(3, fechaInicioSql);
                    ps.setString(4, processInstanceId);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void marcarCursoArchivado(String processInstanceId, String motivo, String observaciones) {
        if (processInstanceId == null || processInstanceId.isBlank()) return;
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String detalle = "[ARCHIVADO - " + motivo + "]" +
                        (observaciones != null && !observaciones.isBlank() ? " " + observaciones : "");
                String sql = "UPDATE curso SET estado = 'ARCHIVADA', " +
                             "descripcion = CASE WHEN descripcion IS NULL OR descripcion = '' THEN ? ELSE descripcion || ' | ' || ? END " +
                             "WHERE process_instance_id = ?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, detalle);
                    ps.setString(2, detalle);
                    ps.setString(3, processInstanceId);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void completarEnFlowable(String taskId, Map<String, Object> payload) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        String jsonBody = OBJECT_MAPPER.writeValueAsString(payload);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(FLOWABLE_BASE_URL + "/runtime/tasks/" + taskId))
                .header("Authorization", "Basic " + basicAuth())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() < 200 || res.statusCode() >= 300) {
            throw new RuntimeException("Flowable rechazó completar la tarea (HTTP " + res.statusCode() + "): " + res.body());
        }
    }

    private List consultarFlowableTasks(String url) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Basic " + basicAuth())
                .header("Accept", "application/json")
                .GET()
                .build();

        HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
        List lista = new ArrayList<>();

        if (res.statusCode() == 200) {
            JsonNode data = OBJECT_MAPPER.readTree(res.body()).path("data");
            for (JsonNode t : data) {
                Map<String, Object> item = new HashMap<>();
                item.put("id", t.path("id").asText());
                item.put("name", t.path("name").asText());
                item.put("taskDefinitionKey", t.path("taskDefinitionKey").asText());
                item.put("formKey", t.path("formKey").isNull() ? "" : t.path("formKey").asText());
                item.put("assignee", t.path("assignee").isNull() ? null : t.path("assignee").asText());
                item.put("processInstanceId", t.path("processInstanceId").asText());
                item.put("createTime", t.path("createTime").asText());
                lista.add(item);
            }
        }
        return lista;
    }

    private Map<String, Object> varFlowable(String name, Object value) {
        Map<String, Object> v = new HashMap<>();
        v.put("name", name);
        v.put("value", value);
        return v;
    }

    private boolean toBool(Object val) {
        if (val instanceof Boolean) return (Boolean) val;
        if (val == null) return false;
        return Boolean.parseBoolean(val.toString().trim());
    }

    private String str(Object o) {
        return o == null ? "" : o.toString().trim();
    }

    private String basicAuth() {
        return Base64.getEncoder().encodeToString(
                (FLOWABLE_REST_USER + ":" + FLOWABLE_REST_PASS).getBytes(StandardCharsets.UTF_8)
        );
    }
}