package com.grupo12.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class FlowableClientService {

    private static final String FLOWABLE_URL = "http://localhost:8080/flowable-ui/process-api/runtime/process-instances";
    private static final String USER = "admin";
    private static final String PASS = "test";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static String iniciarInstanciaProceso(String processDefinitionKey, String nombreEmpresa, boolean esViable) throws Exception {

        // 1. Armar autenticación Basic
        String credenciales = USER + ":" + PASS;
        String basicAuth = Base64.getEncoder().encodeToString(credenciales.getBytes(StandardCharsets.UTF_8));

        // 2. Armar el JSON con variables requeridas
        String jsonBody = "{"
                + "\"processDefinitionKey\": \"" + processDefinitionKey + "\","
                + "\"variables\": ["
                + "  {\"name\": \"esViable\", \"type\": \"boolean\", \"value\": " + esViable + "},"
                + "  {\"name\": \"cantidadCursos\", \"type\": \"integer\", \"value\": 0}"
                + "]"
                + "}";

        // 3. Construir la petición HTTP POST
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(FLOWABLE_URL))
                .header("Authorization", "Basic " + basicAuth)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        // 4. Enviar la petición
        HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 201) {
            JsonNode root = OBJECT_MAPPER.readTree(response.body());
            return root.get("id").asText();
        } else {
            throw new RuntimeException("Error al iniciar instancia en Flowable. Código HTTP: " + response.statusCode() + " - " + response.body());
        }
    }
}