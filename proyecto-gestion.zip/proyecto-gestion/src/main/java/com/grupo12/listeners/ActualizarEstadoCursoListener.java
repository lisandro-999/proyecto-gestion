package com.grupo12.listeners;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;

public class ActualizarEstadoCursoListener implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) {
        // Obtenemos el resultado que dejó el flujo al terminar (FINALIZADO, NO_VIABLE, etc.)
        Object resultado = execution.getVariable("resultadoCurso");
        
        System.out.println(">>> [Local] Estado del curso actualizado a: " + (resultado != null ? resultado : "CERRADO"));
    }
}