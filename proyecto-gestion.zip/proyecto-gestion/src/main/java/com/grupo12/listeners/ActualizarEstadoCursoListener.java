package com.grupo12.listeners;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class ActualizarEstadoCursoListener implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) {
        // Obtener el resultado definido en el camino correspondiente del proceso
        String resultado = (String) execution.getVariable("resultadoCurso");
        // ID o identificador del curso vinculado en la BD institucional
        String cursoId = (String) execution.getVariable("cursoId");

        if (resultado == null || cursoId == null) {
            return;
        }

        // Parámetros de conexión a la base de datos PostgreSQL institucional
        // (Ajustá el nombre de la base, usuario y contraseña según tu docker-compose)
        String url = "jdbc:postgresql://postgres:5432/tu_base_institucional";
        String user = "tu_usuario";
        String password = "tu_password";

        String sql = "UPDATE cursos SET estado = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, resultado);
            pstmt.setLong(2, Long.parseLong(cursoId));
            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}