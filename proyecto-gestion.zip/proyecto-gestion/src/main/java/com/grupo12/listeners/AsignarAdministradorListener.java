package com.grupo12.listeners;

import org.flowable.engine.IdentityService;
import org.flowable.engine.ProcessEngines;
import org.flowable.engine.TaskService;
import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.flowable.idm.api.User;

import java.util.List;

public class AsignarAdministradorListener implements TaskListener {

    @Override
    public void notify(DelegateTask delegateTask) {
        TaskService taskService = ProcessEngines.getDefaultProcessEngine().getTaskService();
        IdentityService identityService = ProcessEngines.getDefaultProcessEngine().getIdentityService();

        // 1. Obtener todos los usuarios del grupo 'Administracion'
        List<User> admins = identityService.createUserQuery().memberOfGroup("administracion").list();

        if (admins == null || admins.isEmpty()) {
            return;
        }

        String mejorAdmin = null;
        long menorCantidadTareas = Long.MAX_VALUE;

        // 2. Contar tareas pendientes asignadas exclusivamente a cada admin
        for (User admin : admins) {
            long tareasPendientes = taskService.createTaskQuery()
                    .taskAssignee(admin.getId())
                    .count();

            // Seleccionar el que tenga menor carga
            if (tareasPendientes < menorCantidadTareas) {
                menorCantidadTareas = tareasPendientes;
                mejorAdmin = admin.getId();
            }
        }

        // 3. Asignar la tarea automáticamente
        if (mejorAdmin != null) {
            delegateTask.setAssignee(mejorAdmin);
        }
    }
}