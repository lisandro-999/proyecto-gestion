package com.grupo12.listeners;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.flowable.engine.impl.context.Context;

public class EvaluarViabilidadListener implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) {
        // 1. Consultamos al motor la cantidad de instancias activas usando el contexto de Flowable
        long cantidad = Context.getProcessEngineConfiguration()
            .getRuntimeService()
            .createProcessInstanceQuery()
            .processDefinitionKey(execution.getProcessDefinitionId().split(":")[0])
            .active()
            .count();

        // 2. Excluimos del conteo la instancia actual que se está evaluando
        long cantidadOtras = Math.max(0, cantidad - 1);

        // 3. Guardamos la variable para que la lea la tabla DMN
        execution.setVariable("cantidadCursos", cantidadOtras);
    }
}