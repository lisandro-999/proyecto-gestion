package com.grupo12.listeners;

import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.ExecutionListener;
import org.flowable.engine.impl.context.Context;
import org.flowable.engine.runtime.ProcessInstance;

import java.util.List;

public class EvaluarViabilidadListener implements ExecutionListener {

    @Override
    public void notify(DelegateExecution execution) {
        String currentProcessInstanceId = execution.getProcessInstanceId();

        RuntimeService runtimeService = Context.getProcessEngineConfiguration().getRuntimeService();

        List<ProcessInstance> activas = runtimeService.createProcessInstanceQuery()
                .processDefinitionKey("curso5")
                .active()
                .list();

        long cantidadOtrasInstancias = activas.stream()
                .filter(pi -> pi.getId() != null && !pi.getId().equals(currentProcessInstanceId))
                .count();

        System.err.println("[EvaluarViabilidadListener] currentId=" + currentProcessInstanceId + " | activas.size()=" + activas.size() + " | otras=" + cantidadOtrasInstancias);

        execution.setVariable("cantidadCursos", (int) cantidadOtrasInstancias);
    }
}