package com.grupo12.delegates;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LiberarAulaDelegate implements JavaDelegate {

    private static final Logger logger = LoggerFactory.getLogger(LiberarAulaDelegate.class);
    private static final String WS_AULAS_LIBERAR_URL = "https://ws-externo-aulas.local/api/v1/liberaciones";

    @Override
    public void execute(DelegateExecution execution) {
        String processInstanceId = execution.getProcessInstanceId();
        Object aulaAsignada = execution.getVariable("aulaAsignada");
        Object codigoReserva = execution.getVariable("codigoReservaAula");

        if (aulaAsignada != null && !aulaAsignada.toString().isBlank()) {
            logger.info(">>> [WS AULAS - LIBERACIÓN] Conectando a {} para liberar aula='{}' (reserva={}, instancia={})...",
                    WS_AULAS_LIBERAR_URL, aulaAsignada, codigoReserva, processInstanceId);

            // Simulación de llamada y respuesta de web service externo
            logger.info(">>> [WS AULAS - LIBERACIÓN] Respuesta OK (200): aula '{}' liberada correctamente.",
                    aulaAsignada);

            execution.removeVariable("aulaAsignada");
            execution.setVariable("aulaLiberada", true);
            execution.setVariable("liberacionAulaWsOk", true);
        } else {
            logger.warn(">>> [WS AULAS - LIBERACIÓN] Instancia {}: no había aulaAsignada para liberar en el web service.",
                    processInstanceId);
            execution.setVariable("aulaLiberada", false);
            execution.setVariable("liberacionAulaWsOk", false);
        }
    }
}