package com.grupo12.delegates;

import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component("reservaAulaDelegate")
public class ReservaAulaDelegate implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) {
        // Asignación del aula para el proceso
        String aulaAsignada = "Aula 204 - Pabellón Argentina";
        
        // Guardamos la variable en el flujo del proceso
        execution.setVariable("aulaAsignada", aulaAsignada);
    }
}