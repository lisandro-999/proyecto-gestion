package com.grupo12.delegates;

import org.flowable.engine.delegate.BpmnError;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

public class ReservarAulaDelegate implements JavaDelegate {

    private static final Logger logger = LoggerFactory.getLogger(ReservarAulaDelegate.class);
    private static final String WS_AULAS_URL = "https://ws-externo-aulas.local/api/v1/reservas";

    @Override
    public void execute(DelegateExecution execution) {
        String processInstanceId = execution.getProcessInstanceId();
        Object fechaInicio = execution.getVariable("fechaInicio");

        logger.info(">>> [WS AULAS - RESERVA] Conectando a {} para instancia {} (fechaInicio={})...",
                WS_AULAS_URL, processInstanceId, fechaInicio);

        Object hayAulasVar = execution.getVariable("hayAulasDisponibles");
        boolean hayAulas = Boolean.TRUE.equals(hayAulasVar)
                || "true".equalsIgnoreCase(String.valueOf(hayAulasVar));

        if (!hayAulas) {
            logger.warn(">>> [WS AULAS - RESERVA] Respuesta 409/404: No hay aulas disponibles para instancia {} (hayAulasDisponibles={})",
                    processInstanceId, hayAulasVar);
            execution.setVariable("aulaReservada", false);
            throw new BpmnError("SIN_AULAS_DISPONIBLES");
        }

        String aula = "Aula 102 - Pabellón 2";
        String reservaId = "WS-RES-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        logger.info(">>> [WS AULAS - RESERVA] Respuesta OK (200): aula='{}', codigoReserva='{}'",
                aula, reservaId);

        execution.setVariable("aulaAsignada", aula);
        execution.setVariable("codigoReservaAula", reservaId);
        execution.setVariable("aulaReservada", true);
    }
}