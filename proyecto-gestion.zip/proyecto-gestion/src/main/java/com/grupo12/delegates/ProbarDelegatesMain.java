package com.grupo12.delegates;

import org.flowable.engine.*;
import org.flowable.engine.impl.cfg.StandaloneInMemProcessEngineConfiguration;
import org.flowable.engine.runtime.Execution;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.flowable.dmn.engine.configurator.DmnEngineConfigurator;

import java.util.HashMap;
import java.util.Map;

public class ProbarDelegatesMain {

    public static void main(String[] args) {
        System.out.println("=== INICIANDO PRUEBA DE DELEGATES ===");

        // 1. Configurar el motor en memoria con soporte DMN
        StandaloneInMemProcessEngineConfiguration cfg = new StandaloneInMemProcessEngineConfiguration();
        cfg.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_TRUE);
        cfg.addConfigurator(new DmnEngineConfigurator());

        ProcessEngine processEngine = cfg.buildProcessEngine();

        RepositoryService repositoryService = processEngine.getRepositoryService();
        RuntimeService runtimeService = processEngine.getRuntimeService();
        TaskService taskService = processEngine.getTaskService();

        // 2. Desplegar el diagrama BPMN y la tabla DMN desde la carpeta static
        repositoryService.createDeployment()
                .addClasspathResource("Curso5.bpmn20.xml")
                .addClasspathResource("Evaluacion de Viabilidad.dmn") //Ruta de DMN
                .deploy();

        // 3. Iniciar el proceso simulando la solicitud inicial viable
        Map<String, Object> vars = new HashMap<>();
        vars.put("esViable", true);
        vars.put("recursosRequeridos", "Presencial");

        ProcessInstance instance = runtimeService.startProcessInstanceByMessage("Solicitud de curso", vars);
        System.out.println("Proceso iniciado con ID: " + instance.getId());

        // Completar la tarea inicial "Registrar y Elaborar propuesta"
        Task propuesta = taskService.createTaskQuery().processInstanceId(instance.getId()).singleResult();
        if (propuesta != null) {
            System.out.println(">>> Completando tarea: " + propuesta.getName());
            taskService.complete(propuesta.getId());
        }

        // Completar la siguiente tarea "Enviar propuesta" (Key: Enviar)
        Task enviarPropuesta = taskService.createTaskQuery().processInstanceId(instance.getId()).taskDefinitionKey("Enviar").singleResult();
        if (enviarPropuesta != null) {
            System.out.println(">>> Completando tarea: " + enviarPropuesta.getName());
            taskService.complete(enviarPropuesta.getId());
        }

        // Ahora el proceso está esperando en el evento intermedio de recepción/señal (Aceptación)
        Execution esperaAceptacion = runtimeService.createExecutionQuery()
                .processInstanceId(instance.getId())
                .messageEventSubscriptionName("Aceptación")
                .singleResult();
        
        if (esperaAceptacion != null) {
            System.out.println(">>> Recibiendo mensaje 'Aceptación'...");
            runtimeService.messageEventReceived("Aceptación", esperaAceptacion.getId());
        } else {
            // Plan B por si el mensaje no tiene tilde en el XML
            Execution esperaSinTilde = runtimeService.createExecutionQuery()
                    .processInstanceId(instance.getId())
                    .messageEventSubscriptionName("Aceptacion")
                    .singleResult();
            if (esperaSinTilde != null) {
                runtimeService.messageEventReceived("Aceptacion", esperaSinTilde.getId());
            }
        }

        // 4. Buscar y completar la tarea "Evaluar Recursos" (Activity_12i2hpf) dentro del subproceso Preparar
        Task evaluarRecursos = taskService.createTaskQuery()
                .processInstanceId(instance.getId())
                .taskDefinitionKey("Activity_12i2hpf")
                .singleResult();

        if (evaluarRecursos != null) {
            System.out.println(">>> Completando 'Evaluar Recursos' para disparar ReservarAulaDelegate...");
            
            Map<String, Object> taskVars = new HashMap<>();
            taskVars.put("recursosRequeridos", "Presencial");
            
            taskService.complete(evaluarRecursos.getId(), taskVars);
        } else {
            System.out.println(">>> [AVISO] No se encontró la tarea 'Evaluar Recursos'.");
        }

        // Validar que el ReservarAulaDelegate se ejecutó correctamente y guardó la variable
        Object aulaAsignada = runtimeService.getVariable(instance.getId(), "aulaAsignada");
        System.out.println("--------------------------------------------------");
        System.out.println(" Variable 'aulaAsignada' tras el delegate: " + aulaAsignada);
        System.out.println("--------------------------------------------------");

        // 5. Enviar mensaje de "Cancelación" para probar el flujo de compensación (LiberarAulaDelegate)
        Execution esperaCancelacion = runtimeService.createExecutionQuery()
                .processInstanceId(instance.getId())
                .messageEventSubscriptionName("Cancelación")
                .singleResult();

        if (esperaCancelacion != null) {
            System.out.println(">>> Enviando mensaje 'Cancelación' para disparar LiberarAulaDelegate...");
            runtimeService.messageEventReceived("Cancelación", esperaCancelacion.getId());
        }

        System.out.println("\n=== PRUEBA DE DELEGATES FINALIZADA ===");
        processEngine.close();
    }
}