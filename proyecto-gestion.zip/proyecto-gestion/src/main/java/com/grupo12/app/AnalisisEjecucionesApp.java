package com.grupo12.app;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AnalisisEjecucionesApp extends JFrame {

    private static final String BASE_URL = "http://localhost:8080/flowable-ui/process-api";
    private static final String AUTH_HEADER = "Basic " + Base64.getEncoder()
            .encodeToString("admin:test".getBytes(StandardCharsets.UTF_8));

    private final HttpClient http = HttpClient.newHttpClient();

    private final DefaultTableModel modelo431 = new DefaultTableModel(
            new Object[]{"Resultado", "Cantidad", "Porcentaje (%)"}, 0);
    private final DefaultTableModel modelo432 = new DefaultTableModel(
            new Object[]{"Rama de preparación", "Instancias", "Duración promedio (seg)"}, 0);
    private final DefaultTableModel modelo433 = new DefaultTableModel(
            new Object[]{"Usuario", "Tareas completadas"}, 0);

    public AnalisisEjecucionesApp() {
        super("Análisis de Ejecuciones - curso5 (Sección 4.3)");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(820, 500);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("4.3.1 Resultados", new JScrollPane(crearTabla(modelo431)));
        tabs.addTab("4.3.2 Preparación paralela", new JScrollPane(crearTabla(modelo432)));
        tabs.addTab("4.3.3 Distribución de tareas", new JScrollPane(crearTabla(modelo433)));

        JButton btnActualizar = new JButton("Actualizar métricas");
        btnActualizar.addActionListener(e -> cargarMetricas());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topPanel.add(btnActualizar);

        add(topPanel, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);

        cargarMetricas();
    }

    private JTable crearTabla(DefaultTableModel model) {
        JTable table = new JTable(model);
        table.setRowHeight(24);
        table.setEnabled(false);
        return table;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void cargarMetricas() {
        try {
            String procJson = getJson("/history/historic-process-instances?processDefinitionKey=curso5&size=200");
            java.util.List instancias = parseObjects(procJson);

            Set terminadasIds = new HashSet();
            for (int i = 0; i < instancias.size(); i++) {
                Map p = (Map) instancias.get(i);
                String endTime = (String) p.get("endTime");
                if (endTime != null && !endTime.isBlank() && !"null".equals(endTime)) {
                    terminadasIds.add(p.get("id"));
                }
            }

            Map resultados = new LinkedHashMap();
            resultados.put("Curso finalizado", 0);
            resultados.put("Cancelación", 0);
            resultados.put("Rechazo de la propuesta", 0);
            resultados.put("Solicitud no viable", 0);
            resultados.put("Cierre por falta de respuesta", 0);

            double sumInscripcionesMs = 0;
            int cntInscripciones = 0;
            double sumMaterialesMs = 0;
            int cntMateriales = 0;
            double sumRecursosMs = 0;
            int cntRecursos = 0;

            String[] idsRecursosFin = {"Virtual", "Aula", "Equipo", "OrFin"};

            for (int i = 0; i < instancias.size(); i++) {
                Map p = (Map) instancias.get(i);
                String pid = (String) p.get("id");
                String actJson = getJson("/history/historic-activity-instances?processInstanceId=" + pid + "&size=250");
                java.util.List acts = parseObjects(actJson);

                Set actIds = new HashSet();
                Map startByAct = new HashMap();
                Map endByAct = new HashMap();

                for (int j = 0; j < acts.size(); j++) {
                    Map a = (Map) acts.get(j);
                    String aid = (String) a.get("activityId");
                    if (aid == null) continue;
                    actIds.add(aid);
                    Instant s = parseInstant((String) a.get("startTime"));
                    Instant e = parseInstant((String) a.get("endTime"));
                    if (s != null) {
                        Instant prevS = (Instant) startByAct.get(aid);
                        if (prevS == null || s.isBefore(prevS)) startByAct.put(aid, s);
                    }
                    if (e != null) {
                        Instant prevE = (Instant) endByAct.get(aid);
                        if (prevE == null || e.isAfter(prevE)) endByAct.put(aid, e);
                    }
                }

                if (terminadasIds.contains(pid)) {
                    String res = clasificarResultado(actIds);
                    if (res != null) {
                        int actual = (Integer) resultados.get(res);
                        resultados.put(res, actual + 1);
                    }
                }

                boolean cancelada = actIds.contains("Event_1g4xmqo") || actIds.contains("EndCancelacion");
                boolean preparacionCompleta = endByAct.get("Preparar") != null || actIds.contains("SubFin");
                if (!cancelada && preparacionCompleta) {
                    Instant insStart = (Instant) startByAct.get("sid-9A2B39EC-DF21-46DF-9CF1-D622AB6187C4");
                    Instant insEnd = (Instant) endByAct.get("Lista");
                    if (insStart != null && insEnd != null && !insEnd.isBefore(insStart)) {
                        sumInscripcionesMs += (insEnd.toEpochMilli() - insStart.toEpochMilli());
                        cntInscripciones++;
                    }

                    Instant matStart = (Instant) startByAct.get("Material");
                    Instant matEnd = (Instant) endByAct.get("Material");
                    if (matStart != null && matEnd != null && !matEnd.isBefore(matStart)) {
                        sumMaterialesMs += (matEnd.toEpochMilli() - matStart.toEpochMilli());
                        cntMateriales++;
                    }

                    Instant recStart = (Instant) startByAct.get("Activity_12i2hpf");
                    Instant recEnd = null;
                    for (int r = 0; r < idsRecursosFin.length; r++) {
                        Instant candidate = (Instant) endByAct.get(idsRecursosFin[r]);
                        if (candidate != null && (recEnd == null || candidate.isAfter(recEnd))) {
                            recEnd = candidate;
                        }
                    }
                    if (recStart != null && recEnd != null && !recEnd.isBefore(recStart)) {
                        sumRecursosMs += (recEnd.toEpochMilli() - recStart.toEpochMilli());
                        cntRecursos++;
                    }
                }
            }

            modelo431.setRowCount(0);
            int totalTerminadas = terminadasIds.size();
            for (Object keyObj : resultados.keySet()) {
                String k = (String) keyObj;
                int cant = (Integer) resultados.get(k);
                double pct = totalTerminadas > 0 ? (cant * 100.0 / totalTerminadas) : 0.0;
                modelo431.addRow(new Object[]{k, cant, String.format(Locale.US, "%.2f%%", pct)});
            }

            modelo432.setRowCount(0);
            modelo432.addRow(new Object[]{
                    "Rama de inscripciones", cntInscripciones,
                    cntInscripciones > 0 ? String.format(Locale.US, "%.2f", (sumInscripcionesMs / cntInscripciones) / 1000.0) : "0.00"
            });
            modelo432.addRow(new Object[]{
                    "Rama de materiales", cntMateriales,
                    cntMateriales > 0 ? String.format(Locale.US, "%.2f", (sumMaterialesMs / cntMateriales) / 1000.0) : "0.00"
            });
            modelo432.addRow(new Object[]{
                    "Rama de recursos", cntRecursos,
                    cntRecursos > 0 ? String.format(Locale.US, "%.2f", (sumRecursosMs / cntRecursos) / 1000.0) : "0.00"
            });

            String tasksJson = getJson("/history/historic-task-instances?processDefinitionKey=curso5&size=500");
            java.util.List tasks = parseObjects(tasksJson);
            Map porUsuario = new TreeMap();
            for (int i = 0; i < tasks.size(); i++) {
                Map t = (Map) tasks.get(i);
                String endTime = (String) t.get("endTime");
                String delReason = (String) t.get("deleteReason");
                String assignee = (String) t.get("assignee");
                boolean completada = endTime != null && !endTime.isBlank() && !"null".equals(endTime);
                boolean cancelada = delReason != null && !delReason.isBlank() && !"null".equals(delReason);
                if (completada && !cancelada && assignee != null && !assignee.isBlank() && !"null".equals(assignee)) {
                    Integer prev = (Integer) porUsuario.get(assignee);
                    porUsuario.put(assignee, (prev == null ? 0 : prev) + 1);
                }
            }

            modelo433.setRowCount(0);
            java.util.List entries = new ArrayList(porUsuario.entrySet());
            entries.sort((a, b) -> Integer.compare(
                    (Integer) ((Map.Entry) b).getValue(),
                    (Integer) ((Map.Entry) a).getValue()
            ));
            for (int i = 0; i < entries.size(); i++) {
                Map.Entry e = (Map.Entry) entries.get(i);
                modelo433.addRow(new Object[]{e.getKey(), e.getValue()});
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error consultando historial de Flowable: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("rawtypes")
    private String clasificarResultado(Set actIds) {
        if (actIds.contains("Fin")) return "Curso finalizado";
        if (actIds.contains("EndCancelacion") || actIds.contains("Event_1g4xmqo")) return "Cancelación";
        if (actIds.contains("Rechazar")) return "Rechazo de la propuesta";
        if (actIds.contains("Flow_0w8xn3l") || actIds.contains("Activity_0iibzwu")) return "Solicitud no viable";
        if (actIds.contains("Limite")) return "Cierre por falta de respuesta";
        return null;
    }

    private String getJson(String path) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + path))
                .header("Authorization", AUTH_HEADER)
                .GET()
                .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() >= 400) {
            throw new RuntimeException("HTTP " + resp.statusCode() + " en " + path);
        }
        return resp.body();
    }

    private Instant parseInstant(String iso) {
        if (iso == null || iso.isBlank() || "null".equals(iso)) return null;
        return Instant.parse(iso);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private java.util.List parseObjects(String json) {
        java.util.List list = new ArrayList();
        int dataIdx = json.indexOf("\"data\"");
        if (dataIdx < 0) return list;
        int arrStart = json.indexOf('[', dataIdx);
        if (arrStart < 0) return list;

        int depth = 0;
        int objStart = -1;
        boolean inString = false;
        boolean escape = false;

        for (int i = arrStart; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escape) { escape = false; continue; }
            if (c == '\\') { escape = true; continue; }
            if (c == '"') { inString = !inString; continue; }
            if (inString) continue;

            if (c == '{') {
                if (depth == 1) objStart = i;
                depth++;
            } else if (c == '}') {
                depth--;
                if (depth == 1 && objStart >= 0) {
                    list.add(parseFlatObject(json.substring(objStart, i + 1)));
                    objStart = -1;
                }
            } else if (c == '[') {
                depth++;
            } else if (c == ']') {
                depth--;
                if (depth == 0) break;
            }
        }
        return list;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private Map parseFlatObject(String objJson) {
        Map map = new HashMap();
        Pattern p = Pattern.compile("\"([^\"]+)\"\\s*:\\s*(\"[^\"]*\"|null|true|false|-?\\d+)");
        Matcher m = p.matcher(objJson);
        while (m.find()) {
            String k = m.group(1);
            String v = m.group(2);
            if (v.startsWith("\"") && v.endsWith("\"")) {
                v = v.substring(1, v.length() - 1);
            }
            map.put(k, v);
        }
        return map;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AnalisisEjecucionesApp().setVisible(true));
    }
}