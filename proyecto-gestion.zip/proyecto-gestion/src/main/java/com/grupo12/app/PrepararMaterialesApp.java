package com.grupo12.app;

import org.flowable.engine.IdentityService;
import org.flowable.engine.ProcessEngine;
import org.flowable.engine.ProcessEngineConfiguration;
import org.flowable.engine.TaskService;
import org.flowable.engine.impl.cfg.StandaloneProcessEngineConfiguration;
import org.flowable.idm.api.Group;
import org.flowable.task.api.Task;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PrepararMaterialesApp extends JFrame {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/flowable";
    private static final String DB_USER = "postgres";
    private static final String DB_PASS = "password";
    private static final String DB_DRIVER = "org.postgresql.Driver";

    private static final String GRUPO_OBJETIVO = "administracion";
    private static final String TASK_DEF_KEY = "Material";

    private transient ProcessEngine processEngine;
    private transient IdentityService identityService;
    private transient TaskService taskService;

    private String usuarioLogueado = null;

    private JTextField txtUsuario;
    private JPasswordField txtClave;
    private JButton btnLogin;
    private JButton btnRefresh;
    private JButton btnReclamar;
    private JButton btnCompletar;
    private JLabel lblEstadoUsuario;
    private JLabel lblMensaje;
    private DefaultListModel<String> listModel;
    private JList<String> listaTareas;

    private final List<Task> tareasMostradas = new ArrayList<>();
    private final Map<String, String> descripcionPorId = new LinkedHashMap<>();

    public PrepararMaterialesApp() {
        super("4.2.1 - Preparación de Materiales (API Java Flowable)");
        inicializarMotorFlowable();
        construirInterfaz();
    }

    private void inicializarMotorFlowable() {
        StandaloneProcessEngineConfiguration cfg = new StandaloneProcessEngineConfiguration();
        cfg.setJdbcUrl(DB_URL);
        cfg.setJdbcUsername(DB_USER);
        cfg.setJdbcPassword(DB_PASS);
        cfg.setJdbcDriver(DB_DRIVER);
        cfg.setDatabaseSchemaUpdate(ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE);
        cfg.setAsyncExecutorActivate(false);

        this.processEngine = cfg.buildProcessEngine();
        this.identityService = processEngine.getIdentityService();
        this.taskService = processEngine.getTaskService();
    }

    private void construirInterfaz() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(760, 480);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Panel superior: Login
        JPanel panelLogin = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        panelLogin.setBorder(BorderFactory.createTitledBorder("Identificación de Administrativo"));

        panelLogin.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField(12);
        panelLogin.add(txtUsuario);

        panelLogin.add(new JLabel("Clave:"));
        txtClave = new JPasswordField(12);
        panelLogin.add(txtClave);

        btnLogin = new JButton("Ingresar");
        panelLogin.add(btnLogin);

        lblEstadoUsuario = new JLabel("No autenticado");
        panelLogin.add(lblEstadoUsuario);

        add(panelLogin, BorderLayout.NORTH);

        // Panel central: Lista de tareas Preparar materiales
        JPanel panelCentro = new JPanel(new BorderLayout(6, 6));
        panelCentro.setBorder(BorderFactory.createTitledBorder("Tareas 'Preparar materiales' (Asignadas o Disponibles para administración)"));

        listModel = new DefaultListModel<>();
        listaTareas = new JList<>(listModel);
        listaTareas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panelCentro.add(new JScrollPane(listaTareas), BorderLayout.CENTER);

        add(panelCentro, BorderLayout.CENTER);

        // Panel inferior: Acciones y mensajes
        JPanel panelSur = new JPanel(new BorderLayout(6, 6));

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        btnRefresh = new JButton("Actualizar tareas");
        btnReclamar = new JButton("Reclamar tarea");
        btnCompletar = new JButton("Completar tarea");

        btnRefresh.setEnabled(false);
        btnReclamar.setEnabled(false);
        btnCompletar.setEnabled(false);

        panelBotones.add(btnRefresh);
        panelBotones.add(btnReclamar);
        panelBotones.add(btnCompletar);
        panelSur.add(panelBotones, BorderLayout.NORTH);

        lblMensaje = new JLabel("Ingresá con un usuario del grupo 'administracion' para consultar tareas.");
        lblMensaje.setBorder(BorderFactory.createEmptyBorder(4, 10, 8, 10));
        panelSur.add(lblMensaje, BorderLayout.SOUTH);

        add(panelSur, BorderLayout.SOUTH);

        // Eventos
        btnLogin.addActionListener(e -> intentarLogin());
        btnRefresh.addActionListener(e -> cargarTareas());
        btnReclamar.addActionListener(e -> reclamarTareaSeleccionada());
        btnCompletar.addActionListener(e -> completarTareaSeleccionada());
    }

    private void intentarLogin() {
        String usuario = txtUsuario.getText().trim();
        String clave = new String(txtClave.getPassword()).trim();

        if (usuario.isEmpty() || clave.isEmpty()) {
            mostrarMensaje("Completá usuario y clave.", true);
            return;
        }

        try {
            boolean ok = identityService.checkPassword(usuario, clave);
            if (!ok) {
                mostrarMensaje("Credenciales inválidas.", true);
                return;
            }

            List<Group> grupos = identityService.createGroupQuery().groupMember(usuario).list();
            boolean perteneceGrupo = false;
            for (Group g : grupos) {
                if (GRUPO_OBJETIVO.equals(g.getId())) {
                    perteneceGrupo = true;
                    break;
                }
            }

            if (!perteneceGrupo) {
                mostrarMensaje("El usuario '" + usuario + "' no pertenece al grupo '" + GRUPO_OBJETIVO + "'.", true);
                return;
            }

            this.usuarioLogueado = usuario;
            lblEstadoUsuario.setText("Conectado: " + usuario + " (" + GRUPO_OBJETIVO + ")");
            btnRefresh.setEnabled(true);
            btnReclamar.setEnabled(true);
            btnCompletar.setEnabled(true);
            mostrarMensaje("Sesión iniciada como '" + usuario + "'.", false);
            cargarTareas();
        } catch (Exception ex) {
            mostrarMensaje("Error al autenticar en Flowable: " + ex.getMessage(), true);
        }
    }

    private void cargarTareas() {
        if (usuarioLogueado == null) return;

        try {
            tareasMostradas.clear();
            descripcionPorId.clear();
            listModel.clear();

            // 1. Tareas ya asignadas al usuario
            List<Task> asignadas = taskService.createTaskQuery()
                    .taskAssignee(usuarioLogueado)
                    .taskDefinitionKey(TASK_DEF_KEY)
                    .orderByTaskCreateTime().asc()
                    .list();

            // 2. Tareas sin asignar candidatas para el grupo 'administracion'
            List<Task> disponiblesGrupo = taskService.createTaskQuery()
                    .taskCandidateGroup(GRUPO_OBJETIVO)
                    .taskUnassigned()
                    .taskDefinitionKey(TASK_DEF_KEY)
                    .orderByTaskCreateTime().asc()
                    .list();

            for (Task t : asignadas) {
                agregarTareaSiNoExiste(t, "ASIGNADA A MÍ (" + usuarioLogueado + ")");
            }
            for (Task t : disponiblesGrupo) {
                agregarTareaSiNoExiste(t, "DISPONIBLE PARA RECLAMAR");
            }

            if (tareasMostradas.isEmpty()) {
                listModel.addElement("No hay tareas 'Preparar materiales' asignadas ni disponibles para reclamar.");
            }
            mostrarMensaje("Tareas actualizadas (" + tareasMostradas.size() + " encontrada(s)).", false);
        } catch (Exception ex) {
            mostrarMensaje("Error al consultar tareas: " + ex.getMessage(), true);
        }
    }

    private void agregarTareaSiNoExiste(Task t, String estadoTexto) {
        if (t == null || descripcionPorId.containsKey(t.getId())) return;
        tareasMostradas.add(t);
        String texto = String.format("[%s] %s | ID: %s | Instancia: %s",
                estadoTexto,
                t.getName() != null ? t.getName() : TASK_DEF_KEY,
                t.getId(),
                t.getProcessInstanceId());
        descripcionPorId.put(t.getId(), texto);
        listModel.addElement(texto);
    }

    private void reclamarTareaSeleccionada() {
        if (usuarioLogueado == null) return;
        Task seleccionada = obtenerTareaSeleccionada();
        if (seleccionada == null) {
            mostrarMensaje("Seleccioná una tarea de la lista para reclamar.", true);
            return;
        }

        try {
            if (seleccionada.getAssignee() != null && !seleccionada.getAssignee().isBlank()) {
                mostrarMensaje("La tarea ya está asignada a '" + seleccionada.getAssignee() + "'.", true);
                return;
            }
            taskService.claim(seleccionada.getId(), usuarioLogueado);
            mostrarMensaje("Tarea '" + seleccionada.getId() + "' reclamada por '" + usuarioLogueado + "'.", false);
            cargarTareas();
        } catch (Exception ex) {
            mostrarMensaje("No se pudo reclamar la tarea: " + ex.getMessage(), true);
        }
    }

    private void completarTareaSeleccionada() {
        if (usuarioLogueado == null) return;
        Task seleccionada = obtenerTareaSeleccionada();
        if (seleccionada == null) {
            mostrarMensaje("Seleccioná una tarea de la lista para completar.", true);
            return;
        }

        try {
            if (!usuarioLogueado.equals(seleccionada.getAssignee())) {
                mostrarMensaje("Primero tenés que reclamar la tarea para poder completarla.", true);
                return;
            }
            taskService.complete(seleccionada.getId());
            mostrarMensaje("Tarea '" + seleccionada.getId() + "' completada correctamente.", false);
            cargarTareas();
        } catch (Exception ex) {
            mostrarMensaje("No se pudo completar la tarea: " + ex.getMessage(), true);
        }
    }

    private Task obtenerTareaSeleccionada() {
        int idx = listaTareas.getSelectedIndex();
        if (idx < 0 || idx >= tareasMostradas.size()) return null;
        return tareasMostradas.get(idx);
    }

    private void mostrarMensaje(String msg, boolean esError) {
        lblMensaje.setText(msg);
        lblMensaje.setForeground(esError ? new Color(185, 28, 28) : new Color(21, 128, 61));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PrepararMaterialesApp app = new PrepararMaterialesApp();
            app.setVisible(true);
        });
    }
}